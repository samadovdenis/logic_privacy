//
//  ARFramework.h
//  ARFramework
//
//  Created by Den on 17.02.2020.
//  Copyright © 2020 Den Samed. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for ARFramework.
FOUNDATION_EXPORT double ARFrameworkVersionNumber;

//! Project version string for ARFramework.
FOUNDATION_EXPORT const unsigned char ARFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ARFramework/PublicHeader.h>


